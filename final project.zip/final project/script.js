const card = document.getElementById('card');
const showLogin = document.getElementById('showLogin');
const showRegister = document.getElementById('showRegister');

showLogin.addEventListener('click', () => {
    card.style.transform = 'rotateY(0deg)';
});

showRegister.addEventListener('click', () => {
    card.style.transform = 'rotateY(180deg)';
});

function handleFormSubmit(event, isLogin) {
    event.preventDefault();

    // Simple simulation of form submission
    if (isLogin) {
        alert('Login successful!');
        window.location.href = 'dashboard.html';
    } else {
        alert('Registration successful!');
        card.style.transform = 'rotateY(0deg)'; // Switch back to the login form
    }
}

document.querySelector('.front form').addEventListener('submit', (event) => handleFormSubmit(event, true));
document.querySelector('.back form').addEventListener('submit', (event) => handleFormSubmit(event, false));

